package kr.pe.playdata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlackAndWhiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
